import Link from "next/link";
import Image from "next/image";

export function Nav({ userName }: { userName?: string | null }) {
  return (
    <header className="border-b">
      <div className="mx-auto flex h-[58px] max-w-4xl items-center gap-6 px-8">
        <Link href="/dashboard" className="flex items-center gap-2.5">
          <Image
            src="/sunpay-mark.png"
            alt="SunPay"
            width={26}
            height={26}
            className="border border-border"
          />
          <span className="text-base font-medium tracking-tight text-foreground">
            sunpay
          </span>
        </Link>
        <nav className="flex gap-4 text-sm text-muted-foreground">
          <Link href="/dashboard" className="transition-colors hover:text-foreground">
            dashboard
          </Link>
          <Link href="/history" className="transition-colors hover:text-foreground">
            history
          </Link>
        </nav>
        <div className="ml-auto flex items-center gap-3 text-sm">
          {userName && <span className="text-muted-foreground">{userName}</span>}
          <a href="/auth/logout" className="text-muted-foreground underline-offset-4 hover:text-foreground hover:underline">
            sign out
          </a>
        </div>
      </div>
    </header>
  );
}
