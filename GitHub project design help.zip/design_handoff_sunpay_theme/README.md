# Handoff: SunPay dark sunset theme

## Overview
This retheme takes the SunPay Next.js app (`app/` in the `ht6-2026` repo) from the
default light shadcn look to a clean, dark, sunset-accented system: near-black
canvas, sunset-orange accent pulled from the SunPay logo, quiet 1px borders,
sharp corners, Inter throughout, and a subtle film-grain overlay.

Because the app is built on shadcn + Tailwind v4 design tokens, **most of the
restyle happens in one file** (`globals.css`). The components (`Card`, `Button`,
`Badge`, `Table`, inputs) already read from those tokens, so retheming the tokens
restyles every page at once. Only two small things need hand edits: the logo/nav,
and a handful of **hardcoded** state colors (`bg-green-600`, `text-amber-600`,
etc.) that bypass the token system.

## About the design files
`reference/SunPay App.dc.html` is a **design reference** — an HTML mockup of all
eight screens showing the intended look. It is not production code to paste in.
Recreate the look in the real app using the steps below (the app already has the
right component library; this is a theming pass, not a rewrite).

## Fidelity
**High-fidelity.** Exact colors, borders, and type are specified below and encoded
in the provided `globals.css`.

---

## How to apply

### 1. Replace `app/src/app/globals.css`
Drop in the provided `src/app/globals.css`. It keeps your existing `@theme inline`
mapping and only changes the `:root` / `.dark` token values (plus two new
`--signal-*` brand colors and a film-grain `body::after`). The app now defaults to
dark — no `.dark` class on `<html>` needed.

Key token changes:
| Token | New value | Meaning |
|---|---|---|
| `--background` | `#0d0d0d` | near-black canvas |
| `--foreground` | `#e0e0e0` | body text |
| `--card` / `--card-foreground` | `#0d0d0d` / `#f0f0f0` | cards = bg + border |
| `--primary` / `--primary-foreground` | `#ec9a54` / `#0d0d0d` | sunset orange buttons |
| `--secondary` | `#1a1a1a` | subtle surface |
| `--muted-foreground` | `#888888` | dim/meta text |
| `--accent` | `#1a1a1a` | hover surface (NOT the orange) |
| `--destructive` | `#cf7a6a` | muted terracotta |
| `--border` / `--input` | `#2a2a2a` / `#333333` | quiet lines |
| `--ring` | `#ec9a54` | focus ring |
| `--radius` | `0rem` | sharp corners |
| `--signal-positive` | `#86b092` | muted sage — success states |
| `--signal-attention` | `#ec9a54` | sunset — floated / covered |

> `--signal-positive` / `--signal-attention` are exposed to Tailwind as
> `signal-positive` / `signal-attention` — use `border-signal-positive`,
> `text-signal-positive`, `bg-signal-attention/10`, etc.

### 2. Add the logo assets + replace the nav
- Copy `public/sunpay-mark.png` and `public/sunpay-logo.png` into `app/public/`.
- Replace `app/src/components/nav.tsx` with the provided file. It renders the mark
  + lowercase `sunpay` wordmark, lowercase nav links (`dashboard`, `history`), and
  a muted `sign out`. (Uses `next/image`.)

### 3. Swap the hardcoded state colors
These classes ignore the token system, so change them by hand. Each is a small,
exact find/replace. The goal: green→sage `signal-positive`, amber→sunset
`signal-attention`, blue→sage, and make filled badges into outlined tags to match
the design.

**`app/src/app/dashboard/page.tsx`** — the `stateBadge` map:
```ts
// FROM
const stateBadge: Record<string, string> = {
  pending: "bg-gray-500",
  charged: "bg-green-600",
  floated: "bg-amber-500",
  settled: "bg-blue-600",
};
// TO — outlined tags in brand signal colors
const stateBadge: Record<string, string> = {
  pending:  "border border-muted-foreground/40 text-muted-foreground bg-transparent",
  charged:  "border border-signal-positive text-signal-positive bg-transparent",
  floated:  "border border-signal-attention text-signal-attention bg-transparent",
  settled:  "border border-signal-positive text-signal-positive bg-transparent",
};
```
Then in the obligations `.map`, change the badge to drop the white fill:
```tsx
// FROM
<Badge className={`${stateBadge[o.state]} text-white`}>{o.state}</Badge>
// TO
<Badge variant="outline" className={stateBadge[o.state]}>{o.state}</Badge>
```
And the "You owe SunPay" number:
```tsx
// FROM
className={`text-4xl font-bold ${outstanding > 0 ? "text-amber-600" : "text-green-600"}`}
// TO
className={`text-4xl font-light ${outstanding > 0 ? "text-signal-attention" : "text-signal-positive"}`}
```

**`app/src/app/history/page.tsx`** — the "everything adds up" badge:
```tsx
// FROM
<Badge className="bg-green-600 text-white hover:bg-green-600">Everything adds up ✓</Badge>
// TO
<Badge variant="outline" className="border-signal-positive text-signal-positive">Everything adds up ✓</Badge>
```
(The `variant="destructive"` "doesn't add up" badge already follows `--destructive`.)

**`app/src/app/groups/[id]/page.tsx`** — the "accepted" badge:
```tsx
// FROM
<Badge className="bg-green-600 text-white hover:bg-green-600">accepted</Badge>
// TO
<Badge variant="outline" className="border-signal-positive text-signal-positive">accepted</Badge>
```
("invited" uses `variant="secondary"` — already themed.)

**`app/src/app/split/[id]/review/page.tsx`** — the odd-cent marker:
```tsx
// FROM
<span className="ml-1 text-amber-600" ...>+{...}¢</span>
// TO
<span className="ml-1 text-signal-attention" ...>+{...}¢</span>
```

**`app/src/app/split/[id]/execution-view.tsx`** — the `StatusBadge`:
```tsx
// charged / settled: FROM bg-green-600 text-white  TO variant="outline" className="border-signal-positive text-signal-positive"  (label: charged ✓)
// floated:           FROM bg-amber-500 text-white  TO variant="outline" className="border-signal-attention text-signal-attention"
```

**`app/src/app/groups/[id]/stays/stays-search.tsx`** — listing badges + stars:
```tsx
// "In budget ✓":  FROM bg-green-600 text-white  TO variant="outline" className="border-signal-positive text-signal-positive"
// "Over budget":  variant="destructive" already follows --destructive (terracotta) — leave as is.
// star rating:    text-amber-500  →  text-signal-attention
// listing thumbnails: add grayscale to match the halftone look, e.g.
//   className="h-36 w-full object-cover grayscale contrast-110"
```

**`app/src/app/join/[code]/page.tsx`** — the "already a member" line:
```tsx
// FROM text-green-700  TO text-signal-positive
```

That's the full list — everything else follows the tokens automatically.

---

## Screens (what each should look like)
All eight are in `reference/SunPay App.dc.html`. Summary of the treatment shared
across them:
- **Nav**: 58px, bottom border `#2a2a2a`, mark + lowercase `sunpay`, lowercase links.
- **Page title**: light weight (300), `-0.5px` tracking, `#f0f0f0`.
- **Section labels** (e.g. "your groups", "recent obligations"): 0.72rem, uppercase,
  letter-spacing ~2.5px, `#888888`.
- **Cards / rows**: 1px `#333` border, no radius, no shadow; nested rows 1px border.
- **Primary buttons**: `#ec9a54` bg, `#0d0d0d` text.
- **Tags/badges**: outlined (1px), uppercase, ~0.6rem — colored per state above.
- **Money**: tabular figures; the dashboard hero number uses a sunset gradient
  (optional — a flat `text-signal-attention` is the token-driven equivalent).

Screen list: `dashboard`, `history`, `groups/[id]`, `groups/new`, `join/[code]`,
`split/[id]/review`, `split/[id]` (execution), `groups/[id]/stays`.

## Design tokens
See the table in step 1 and the CSS variables in `src/app/globals.css`.

## Assets
- `public/sunpay-mark.png` — app icon / mark (rounded black tile, sunset sun + cream S).
- `public/sunpay-logo.png` — full wordmark (for splash/marketing; nav uses the mark + text).

## Files in this bundle
```
README.md                       ← this file
src/app/globals.css             ← drop-in replacement (the main retheme)
src/components/nav.tsx          ← drop-in replacement (logo + nav)
public/sunpay-mark.png          ← copy into app/public/
public/sunpay-logo.png          ← copy into app/public/
reference/SunPay App.dc.html    ← visual reference for all 8 screens
```
